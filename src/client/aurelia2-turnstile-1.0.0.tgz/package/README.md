﻿# aurelia2-turnstile

A Cloudflare Turnstile integration for Aurelia 2 applications. Provides a simple custom element to render the [Cloudflare Turnstile](https://developers.cloudflare.com/turnstile/) CAPTCHA widget.

## Installation

```bash
npm install aurelia2-turnstile
```

## Register the Plugin

Inside of `main.ts`/`main.js`, register the plugin with your sitekey:

```ts
import Aurelia from 'aurelia';
import { TurnstileConfiguration } from 'aurelia2-turnstile';
import { MyApp } from './my-app';

Aurelia.register(
  TurnstileConfiguration.configure({
    sitekey: 'YOUR_CLOUDFLARE_TURNSTILE_SITE_KEY',
  })
).app(MyApp).start();
```

### Configuration Options

| Option      | Type                              | Default                                                                 | Description                          |
|-------------|-----------------------------------|-------------------------------------------------------------------------|--------------------------------------|
| `sitekey`   | `string`                          | `''`                                                                    | Your Cloudflare Turnstile site key   |
| `theme`     | `'light'` \| `'dark'` \| `'auto'` | `'auto'`                                                                | Widget theme                         |
| `scriptUrl` | `string`                          | `'https://challenges.cloudflare.com/turnstile/v0/api.js'` | URL for the Turnstile script         |

### Callback-style Configuration

```ts
import { TurnstileConfiguration } from 'aurelia2-turnstile';

Aurelia.register(
  TurnstileConfiguration.customize((config) => {
    config.options({
      sitekey: 'YOUR_SITE_KEY',
      theme: 'auto',
    });
  })
);
```

## Usage

When a user completes the Turnstile challenge, the plugin dispatches a `turnstile-verified` custom DOM event with the token in `$event.detail.token`. You can also use the `callback` bindable directly.

### Using the Event (Recommended)

The `turnstile-verified` event is the recommended approach because Aurelia's `.trigger` binding handles method context automatically — no need for `.bind(this)` in your constructor.

**Template (`contact-page.html`):**

```html
<form submit.trigger="sendContactInfo()">
  <label>Name</label>
  <input type="text" value.bind="contactViewModel.name & validate" />

  <label>Email</label>
  <input type="email" value.bind="contactViewModel.email & validate" />

  <label>Subject</label>
  <input type="text" value.bind="contactViewModel.subject & validate" />

  <label>Message</label>
  <textarea value.bind="contactViewModel.message & validate"></textarea>

  <turnstile turnstile-verified.trigger="onTurnstileSuccess($event)"></turnstile>

  <button type="submit">Send</button>
</form>
```

**View Model (`contact-page.ts`):**

```ts
import { inject, newInstanceForScope } from '@aurelia/kernel';
import { IRouter } from '@aurelia/router';
import { IValidationRules } from '@aurelia/validation';
import { IValidationController } from '@aurelia/validation-html';
import { HomeService } from './home-service.js';

interface IContactViewModel {
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
  turnstileToken: string;
}

@inject(HomeService, IRouter, newInstanceForScope(IValidationController), IValidationRules)
export class ContactPage {
  private contactViewModel: IContactViewModel = {
    name: '', email: '', phone: '', subject: '', message: '', turnstileToken: ''
  };

  constructor(
    private readonly homeService: HomeService,
    private readonly router: IRouter,
    private validationController: IValidationController,
    private validationRules: IValidationRules
  ) { }

  async binding() {
    this.validationRules
      .on(this.contactViewModel)
      .ensure('name').required().withMessage('Name is required')
      .ensure('email').required().email().withMessage('A valid Email is required')
      .ensure('subject').required().withMessage('Subject is required')
      .ensure('message').required().withMessage('Message is required');
  }

  private onTurnstileSuccess(event: CustomEvent): void {
    this.contactViewModel.turnstileToken = event.detail.token;
  }

  private async sendContactInfo(): Promise<void> {
    const result = await this.validationController.validate();
    if (!result.valid) {
      return;
    }

    if (!this.contactViewModel.turnstileToken) {
      console.error('Turnstile token is missing. Please complete the CAPTCHA.');
      return;
    }

    await this.homeService.sendContactInfo(this.contactViewModel);
    await this.router.load('home');
  }
}
```

### Using the Callback Bindable

You can also use the `callback` bindable directly. Note that you need to `.bind(this)` the method in your constructor to preserve context.

```html
<turnstile callback.bind="onTurnstileSuccess"></turnstile>
```

```ts
export class ContactPage {
  constructor() {
    this.onTurnstileSuccess = this.onTurnstileSuccess.bind(this);
  }

  private onTurnstileSuccess(token: string): void {
    this.turnstileToken = token;
  }
}
```

### Bindable Properties

All bindable properties are optional if the corresponding value is provided via plugin configuration.

| Property    | Type                       | Description                                                                 |
|-------------|----------------------------|-----------------------------------------------------------------------------|
| `sitekey`   | `string`                   | Overrides the configured site key for this instance                         |
| `callback`  | `(token: string) => void`  | Called with the verification token on successful challenge completion       |
| `theme`     | `string`                   | Overrides the configured theme (`'light'`, `'dark'`, or `'auto'`)          |
| `scriptUrl` | `string`                   | Overrides the configured script URL                                        |

### Events

| Event                | Detail                | Description                                         |
|----------------------|-----------------------|-----------------------------------------------------|
| `turnstile-verified` | `{ token: string }`   | Dispatched when the user passes the Turnstile challenge |

### Override Configuration Per-Instance

```html
<turnstile sitekey="DIFFERENT_KEY" theme="dark" turnstile-verified.trigger="onVerify($event)"></turnstile>
```

### Multiple Widgets

You can use multiple `<turnstile>` elements on a single page. The script is loaded only once regardless of how many widgets are rendered.

```html
<turnstile turnstile-verified.trigger="onVerifyForm1($event)"></turnstile>
<turnstile turnstile-verified.trigger="onVerifyForm2($event)" theme="dark"></turnstile>
```

## Server-Side Verification

The token must be verified on your server by calling the Cloudflare siteverify endpoint:

```
POST https://challenges.cloudflare.com/turnstile/v0/siteverify
```

With the body:

```json
{
  "secret": "YOUR_SECRET_KEY",
  "response": "TOKEN_FROM_EVENT"
}
```

### .NET Example

```csharp
using System.Net.Http.Json;
using Microsoft.Extensions.Configuration;

public sealed class TurnstileVerificationService(HttpClient httpClient, IConfiguration configuration)
{
  private readonly HttpClient httpClient = httpClient;
  private readonly IConfiguration configuration = configuration;

  public async Task<bool> VerifyTokenAsync(string token, string? remoteIp = null, CancellationToken cancellationToken = default)
  {
    var secretKey = configuration["Turnstile:SecretKey"];

    if (string.IsNullOrWhiteSpace(secretKey))
      throw new InvalidOperationException("Turnstile:SecretKey is not configured.");

    if (string.IsNullOrWhiteSpace(token))
      return false;

    var form = new Dictionary<string, string>
    {
      ["secret"] = secretKey,
      ["response"] = token
    };

    if (!string.IsNullOrWhiteSpace(remoteIp))
      form["remoteip"] = remoteIp;

    using var content = new FormUrlEncodedContent(form);
    using var response = await httpClient
      .PostAsync("https://challenges.cloudflare.com/turnstile/v0/siteverify", content, cancellationToken)
      .ConfigureAwait(false);

    if (!response.IsSuccessStatusCode)
      return false;

    var payload = await response.Content
      .ReadFromJsonAsync<TurnstileVerifyResponse>(cancellationToken: cancellationToken)
      .ConfigureAwait(false);

    return payload?.Success == true;
  }

  private sealed class TurnstileVerifyResponse
  {
    public bool Success { get; set; }
  }
}
```

Call this service before accepting the form submission. The client-side token should be treated as untrusted until the server verifies it successfully.

See the [Cloudflare Turnstile docs](https://developers.cloudflare.com/turnstile/get-started/server-side-validation/) for full details.
